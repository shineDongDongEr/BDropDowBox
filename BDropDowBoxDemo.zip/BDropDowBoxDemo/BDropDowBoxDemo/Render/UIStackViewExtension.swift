//
//  UIStackViewExtension.swift
//  BDropDowBoxDemo
//
//  Created by laidongling on 2024/4/25.
//

import UIKit

extension UIStackView {
    func removeAllArrangedSubviews() {
        arrangedSubviews.forEach { view in
            removeArrangedSubview(view)
            view.removeFromSuperview()
        }
    }
}
