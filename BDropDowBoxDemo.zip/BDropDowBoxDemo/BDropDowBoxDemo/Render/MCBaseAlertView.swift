
//
//  BaseAlertView.swift
//  MCBaseAlertView
//
//  Created by zc_mc on 2021/9/15.
//

import UIKit

/// 动画类型
enum AlertAnimation {
    
    // 从上往下
    case top
    case bottom
    case left
    case right
    // 渐出
    case fade
    // 回弹
    case pop
    case none
}

class MCAlertController: UIViewController {
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .all
    }
    
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    
    override var childForHomeIndicatorAutoHidden: UIViewController? {
        return nil
    }
}


public class NibView: UIView {
    
    var view: UIView!
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        
        loadNib()
        
        setupSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        loadNib()
        
        setupSubviews()
    }
    
    /// 配置子视图
    open func setupSubviews() {
        
    }
//    deinit {
//        print(self, "deinit")
//    }
}

private extension NibView {
    
    func loadNib() {
        
        backgroundColor = UIColor.clear
        
        view = loadXib()
        
        view.frame = bounds
        
        addSubview(view)
        
        view.translatesAutoresizingMaskIntoConstraints = false
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[childView]|", options: [], metrics: nil, views: ["childView": view as Any]))
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[childView]|",  options: [], metrics: nil, views: ["childView": view as Any]))

    }
}

extension UIView {
    
   @objc func loadXib() -> UIView {
        
        let bundle = Bundle(for: type(of: self))
        
        let nibName = type(of: self).description().components(separatedBy: ".").last!
        
        let nib = UINib(nibName: nibName, bundle: bundle)
        
        return nib.instantiate(withOwner: self, options: nil).first as! UIView
    }
    
}


