//
//  DLSignSearchView.swift
//  AnkerboxManager
//
//  Created by laidongling on 2024/4/22.
//

import UIKit

typealias StringBlock = (String) -> ()
typealias EmptyBlock = () -> ()

class DLSignSearchView: NibView {

	var searchHandle: StringBlock?
	var clearClick: EmptyBlock?
	
	@IBOutlet weak var myTxd: UITextField!
	@IBOutlet weak var clearBtn: UIButton!
	
	
	// MARK: - init
	convenience init(searchBlock: StringBlock?, clearBlock: EmptyBlock?) {
		self.init(frame: .zero)
		searchHandle = searchBlock
		clearClick = clearBlock
	}
	
//	required init?(coder aDecoder: NSCoder) {
//		fatalError("init(coder:) has not been implemented")
//	}
	
	
	// MARK: - lifeCycle
	override func setupSubviews() {
		super.setupSubviews()
		
	}
	
	

	// MARK: - action
	@IBAction func clearClick(_ sender: UIButton) {
		clearClick?()
	}
	
	@IBAction func searchClick(_ sender: UITapGestureRecognizer) {
		
		searchHandle?(myTxd.text ?? "")
	}
}
