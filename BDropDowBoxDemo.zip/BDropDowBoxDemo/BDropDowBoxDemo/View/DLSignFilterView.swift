//
//  DLSignFilterView.swift
//  AnkerboxManager
//
//  Created by laidongling on 2024/4/23.
//

import UIKit

class DLSignFilterView: DLFilterView {

	func setupDatas(items: [DLFilterItemModel]){
		super.setupItems(items: items)
	}
}
