//
//  ViewController.swift
//  BDropDowBoxDemo
//
//  Created by laidongling on 2024/4/24.
//

import UIKit

class ViewController: UIViewController {

    // MARK: - lazy
    lazy var topSearchView: DLSignSearchView = {
        let searchView = DLSignSearchView(searchBlock: { [weak self] string in
            guard let self = self else { return }
            
            
        }, clearBlock: {
            
        })
        return searchView
    }()
    
    // MARK: - 下拉框数据变化回调
    private lazy var topFilterView: DLSignFilterView = {
        let filterView = DLSignFilterView.init(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 38))
        return filterView
    }()
    
    // MARK: - lifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        let tempArray = [
            DLFilterItemModel.teamItem(),
            DLFilterItemModel.stausItem(),
            DLFilterItemModel.conditionItem(),
            DLFilterItemModel.orderItem(),
            DLFilterItemModel.moreItem()
        ]
        topFilterView.setupItems(items: tempArray)
        
    }
    
    // MARK: - proviteMethod
    func setupUI(){
        
        view.addSubviews([topSearchView, topFilterView])
        topSearchView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(44)
            make.height.equalTo(52)
        }
        topFilterView.snp.makeConstraints { make in
            make.left.right.equalToSuperview()
            make.top.equalTo(topSearchView.snp.bottom)
            make.height.equalTo(38)
        }
        
    }
}

extension UIView{
    /// EZSE: add multiple subviews
    public func addSubviews(_ views: [UIView]) {
        views.forEach { [weak self] eachView in
            self?.addSubview(eachView)
        }
    }  
}

