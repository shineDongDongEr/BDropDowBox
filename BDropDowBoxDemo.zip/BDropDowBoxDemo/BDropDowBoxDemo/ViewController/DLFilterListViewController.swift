//
//  DLFilterListViewController.swift
//  AnkerboxManager
//
//  Created by laidongling on 2024/4/22.
//

import UIKit

protocol DLFilterListViewControllerDelegate: NSObject{
	func filterVcDidCancle(listVc: DLFilterListViewController)
	func filterResultDidChange(listVc: DLFilterListViewController, type: DLSignFilterStyle, paramDict: [String: Any])
}

enum DLSignFilterStyle: Int {
	case team = 0
	case status = 1
	case condition = 2
	case order = 3
	case more = 4

}

class DLFilterListViewController: UIViewController {
	
	weak var delegate: DLFilterListViewControllerDelegate?
	weak var itemModel: DLFilterItemModel?
	var index: Int = 0
	
	@IBOutlet weak var contentView: UIView!
	
	var style: DLSignFilterStyle?
	
	// MARK: - init
	convenience init(_ style: DLSignFilterStyle) {
		self.init()
		self.style = style
	}
	
	// MARK: - lifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
		view.clipsToBounds = true

    }
	
	override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.delegate?.filterVcDidCancle(listVc: self)
	}
	
	// MARK: - privateMethod
	//***************需要动画就添加以下两方法********************
	func showAnimation(){
		DispatchQueue.main.async{
            self.contentView.transform = CGAffineTransform(translationX: 0, y: -self.contentView.frame.size.height)
			self.view.backgroundColor = .clear
			UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 0.1, options: .curveEaseInOut) {
				self.contentView.transform = .identity
                self.view.backgroundColor =  UIColor.black.withAlphaComponent(0.5)
			}
		}
	}
	
	func dismissWithAimation(){
		DispatchQueue.main.async {
			UIView.animate(withDuration:0.3, delay: 0,  usingSpringWithDamping: 1.0, initialSpringVelocity: 0.1, options: .curveEaseInOut) {
                self.contentView.transform = CGAffineTransform(translationX: 0, y: -self.contentView.frame.size.height)
				self.view.backgroundColor = .clear
			}completion: { finished in
				self.contentView.transform = .identity
				self.view.removeFromSuperview()
			}
		}
	}
	
	// MARK: - action
	
	@IBAction func sureBtnClick(_ sender: Any) {
        self.delegate?.filterVcDidCancle(listVc: self)
	}
}

