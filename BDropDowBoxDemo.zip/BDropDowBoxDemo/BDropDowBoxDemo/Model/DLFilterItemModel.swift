//
//  DLFilterItemModel.swift
//  AnkerboxManager
//
//  Created by laidongling on 2024/4/22.
//

import UIKit

class DLFilterItemModel: NSObject {
	var title: String = ""
	var listVc: DLFilterListViewController?
	
	//团队
	static func teamItem() -> DLFilterItemModel{
		let teamModel =  DLFilterItemModel()
		teamModel.title = "团队"
		teamModel.listVc = DLFilterListViewController(.team)
		return teamModel
	}
	
	//状态
	static func stausItem() -> DLFilterItemModel{
		let statusModel =  DLFilterItemModel()
		statusModel.title = "状态"
		statusModel.listVc = DLFilterListViewController(.status)
		return statusModel
	}
	
	//条件
	static func conditionItem() -> DLFilterItemModel{
		let conditionModel =  DLFilterItemModel()
		conditionModel.title = "条件"
		conditionModel.listVc = DLFilterListViewController(.condition)
		return conditionModel
	}
	
	//排序
	static func orderItem() -> DLFilterItemModel{
		let orderModel =  DLFilterItemModel()
		orderModel.title = "排序"
		orderModel.listVc = DLFilterListViewController(.order)
		return orderModel
	}
	
	//更多
	static func moreItem() -> DLFilterItemModel{
		let moreModel =  DLFilterItemModel()
		moreModel.title = "更多"
		moreModel.listVc = DLFilterListViewController(.more)
		return moreModel
	}
}
