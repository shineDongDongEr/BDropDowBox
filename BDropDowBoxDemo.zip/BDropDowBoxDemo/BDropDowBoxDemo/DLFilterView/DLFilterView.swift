//
//  DLFilterView.swift
//  AnkerboxManager
//
//  Created by laidongling on 2024/4/22.
//

import UIKit
import SnapKit


class DLFilterView: UIView {
	
	var items: [DLFilterItemModel] = []
	//记录当前选中展开的item
	var currentOpenItem: DLFilterItemModel?
	//当前选中的itemIndex
	var currentIndex: Int = 0
	//标题View
	lazy var titleView: DLFilterTitleView = {
		let titleView = DLFilterTitleView()
		return titleView
	}()
		
	func setupItems(items: [DLFilterItemModel]){
		guard items.count > 0 else { return }
		self.items = items
		items.enumerated().forEach { (i, model) in
			model.listVc?.delegate = self
			model.listVc?.itemModel = model
			model.listVc?.index = i
		}
		if titleView.superview != nil{
			titleView.removeFromSuperview()
		}
		//赋值标题视图的内容
		titleView.items = items
		titleView.delegate = self
		addSubview(titleView)
		titleView.snp.makeConstraints { make in
			make.edges.equalToSuperview()
		}
	}
}

//listVc的代理回调
extension DLFilterView: DLFilterListViewControllerDelegate{
	func filterVcDidCancle(listVc: DLFilterListViewController) {
        self.hiddenContentList(animate: true)
        self.titleView.closeAllSelectStatus()
	}
	
	func filterResultDidChange(listVc: DLFilterListViewController, type: DLSignFilterStyle, paramDict: [String : Any]) {
		
	}
}

//标题View的代理回调
extension DLFilterView: DLFilterTitleViewDelegate{
	func didSelectAtIndex(filterView: DLFilterTitleView, index: Int) {
		let item = self.items[index]
		self.currentIndex = index
		if item == currentOpenItem{
			//收起view
			hiddenContentList(animate: true)
		}else{
			//展开view
			showContentListFromItem(item: item)
		}
		
	}
	
	func showContentListFromItem(item: DLFilterItemModel){
		var showAnimation = true
		if self.currentOpenItem != nil{
			showAnimation = false
		}
		hiddenContentList(animate: showAnimation)
		currentOpenItem = item
		if let placeView = item.listVc?.view{
            placeView.backgroundColor =  UIColor.black.withAlphaComponent(0.5)
            self.superview?.addSubview(placeView)
            self.superview?.bringSubviewToFront(placeView)
			placeView.snp.makeConstraints { make in
				make.left.right.equalTo(self)
				make.bottom.equalToSuperview()
                make.top.equalToSuperview().offset(self.frame.size.height + self.frame.origin.y)
			}
		}
		if showAnimation == true{
			if let vc = item.listVc{
				vc.showAnimation()
			}
		}
		
	}
	
	func hiddenContentList(animate: Bool){
		if self.currentOpenItem != nil{
			if animate == true{
				currentOpenItem?.listVc?.dismissWithAimation()
			}else{
				currentOpenItem?.listVc?.view.removeFromSuperview()
			}
			currentOpenItem = nil
		}
	}
	
}

