//
//  DLFilterTitleView.swift
//  AnkerboxManager
//
//  Created by laidongling on 2024/4/22.
//

import UIKit

protocol DLFilterTitleViewDelegate: NSObject{

	func didSelectAtIndex(filterView: DLFilterTitleView, index: Int)
}

class DLFilterTitleView: NibView {

	@IBOutlet weak var line: UIView!
	@IBOutlet weak var stackView: UIStackView!
	
	weak var delegate: DLFilterTitleViewDelegate?
	
	var isLineHidden = false
	
	var items: [DLFilterItemModel] = []{
		didSet{
			//清空容器子视图
			stackView.removeAllArrangedSubviews()
			if items.count > 0{
				for (i, item) in items.enumerated(){
					let itemView = DLFilterTitleItemView()
					itemView.placeholderText = item.title
					itemView.actionButton.tag = i
					itemView.actionButton.addTarget(self, action: #selector(DLFilterTitleView.buttonDidClick(btn:)), for: .touchUpInside)
					stackView.addArrangedSubview(itemView)
				}
				line.isHidden = isLineHidden
			}
		}
	}
	
	override func setupSubviews() {
		super.setupSubviews()
		
	}
	
	@objc func buttonDidClick(btn: UIButton){
		stackView.arrangedSubviews.enumerated().forEach { i, view in
			if let v = view as? DLFilterTitleItemView{
				if i != btn.tag{
					v.isSelect = false
				}else{
					v.isSelect = !v.isSelect
				}
			}
		}
		delegate?.didSelectAtIndex(filterView: self, index: btn.tag)
	}

	//设置高亮值以及选中状态
	func setHighlitedStatus(index: Int, highlightValue: String, isSelect: Bool){
		guard index >= 0 && index < stackView.arrangedSubviews.count else { return }
		if let itemView = stackView.arrangedSubviews[index] as? DLFilterTitleItemView{
			itemView.text = highlightValue
			itemView.isSelect = isSelect
		}
	}
	
	//关闭所有选中状态
	func closeAllSelectStatus(){
		stackView.arrangedSubviews.enumerated().forEach { i, view in
			if let v = view as? DLFilterTitleItemView{
				v.isSelect = false
			}
		}
	}
}
