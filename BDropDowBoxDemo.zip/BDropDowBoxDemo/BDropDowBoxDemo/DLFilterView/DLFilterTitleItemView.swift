//
//  DLFilterTitleItemView.swift
//  AnkerboxManager
//
//  Created by laidongling on 2024/4/22.
//

import UIKit

class DLFilterTitleItemView: NibView {

	@IBOutlet weak var actionButton: UIButton!

	@IBOutlet weak var arrowImageView: UIImageView!
	
	@IBOutlet weak var titleLabel: UILabel!
	
	//记录最终是否高亮
	var isHighlited = false
	
	//没有值的占位文字
	var placeholderText: String?{
		didSet{
			titleLabel.text = placeholderText ?? ""
			update()
		}
	}
	
	//值文字
	var text: String?{
		didSet{
			if let txt = text, txt.count > 0{
				titleLabel.text = txt
			}else{
				titleLabel.text = placeholderText ?? ""
			}
			update()
		}
	}
	
	//是否选中
	var isSelect: Bool = false{
		didSet{
			update()
		}
	}
	
	// MARK: - lifeCycle
	override func setupSubviews() {
		super.setupSubviews()
		
	}
	
	// MARK: - privateMethod
	func update(){
        if self.text?.count ?? 0 > 0 || self.isSelect == true{
            titleLabel.textColor = UIColor.green
			isHighlited = true
		}else{
            titleLabel.textColor = UIColor.black
			isHighlited = false
		}
		var img = UIImage(named: "icon_up")
		img = img?.withRenderingMode(.alwaysTemplate)
		arrowImageView.image = img
        arrowImageView.tintColor = isHighlited ? UIColor.green : UIColor.black
		arrowImageView.transform = isSelect ? CGAffineTransform.init(rotationAngle: Double.pi) : CGAffineTransform.identity
		
	}
}
